CHECKOUT BY AMAZON POST-ORDER MANAGEMENT SAMPLE CODE
Author: Joshua Wong
Copyright: 2007-2008 Amazon Technologies, Inc
*-*-**-***-*****-********-*************
 
*-*-**-***-*****-********-*************
CONTENT SECTIONS (in order of appearance)
*-*-**-***-*****-********-*************
	INTRODUCTION
	PREREQUISITES
	RELEASE NOTES
	SUPPORT & PROJECT HOME
	LINKS
*-*-**-***-*****-********-*************
INTRODUCTION
*-*-**-***-*****-********-*************
	Please understand that by installing Checkout by Amazon post-order management sample
        code, you are agreeing to understand and abide by the terms of the license, as written in LICENSE.txt.  
	Important links are grouped together in a separate section for your convenience.  The most current documentation on Checkout by Amazon can be found on its website.  

*-*-**-***-*****-********-*************
PREREQUISITES
*-*-**-***-*****-********-*************
Please have the following software packages available on your systems
before running the demo.

1. PHP 5
2. PEAR - The PEAR package. PEAR Base System See: http://pear.php.net/package/PEAR
3. PEAR HTTP_Request - PEAR PHP HTTP_Request package. Provides an easy way to perform HTTP requests. See: http://pear.php.net/package/HTTP_Request
4. PEAR Mail_Mime - PEAR php Mail_Mime package. Mail_Mime provides classes to create mime messages. See: http://pear.php.net/package/Mail_Mime
5. PEAR Mail_mimeDecode - PEAR php Mail mimeDecode package. Provides a class to decode mime messages. See: http://pear.php.net/package/Mail_mimeDecode
6. PEAR Net_Socket - PEAR php Net_Socket package. Network Socket Interface See: http://pear.php.net/package/Net_Socket
7. PEAR Net_URL - PEAR Net_URL package. Easy parsing of Urls See: http://pear.php.net/package/Net_URL
8. PEAR Soap - PEAR Soap package. SOAP Client/Server for PHP See: http://pear.php.net/package/SOAP
9. PEAR XML_Parser - PEAR XML_Parser package. XML parsing class based on PHP's bundled expat See: http://pear.php.net/package/XML_Parser
10. PEAR XML_Serializer - PEAR XML_Serializer package. Swiss-army knife for reading and writing XML files. Creates XML files from data structures and vice versa. See: http://pear.php.net/package/XML_Serializer.


*-*-**-***-*****-********-*************
RELEASE NOTES 
*-*-**-***-*****-********-*************
(1) Carefully follow all instructions in INSTALLATION_GUIDE.txt 
(2) You must have set up an Amazon Seller account & have your merchant token
(3) To read more about your merchant token, please view Seller Central help: https://sellercentral.amazon.com/gp/help/

*-*-**-***-*****-********-*************
SUPPORT & PROJECT HOME
*-*-**-***-*****-********-*************
	The latest documentation on Checkout by Amazon can be found at in the LINKS section below.
*-*-**-***-*****-********-*************
LINKS
*-*-**-***-*****-********-*************
	Checkout by Amazon Documentation & Seller Central
		https://sellercentral.amazon.com/gp/help/ 

