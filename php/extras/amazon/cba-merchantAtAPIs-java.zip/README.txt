CHECKOUT BY AMAZON POST-ORDER MANAGEMENT SAMPLE CODE
Author: Joshua Wong
Copyright: 2007-2008 Amazon Technologies, Inc
*-*-**-***-*****-********-*************
 
*-*-**-***-*****-********-*************
CONTENT SECTIONS (in order of appearance)
*-*-**-***-*****-********-*************
	INTRODUCTION
	PREREQUISITES
	RELEASE NOTES
	SUPPORT & PROJECT HOME
	LINKS
*-*-**-***-*****-********-*************
INTRODUCTION
*-*-**-***-*****-********-*************
	Please understand that by installing Checkout by Amazon post-order management sample
    code, you are agreeing to understand and abide by the terms of the license, as written in LICENSE.txt.
	Important links are grouped together in a separate section for your convenience.
	The most current documentation on Checkout by Amazon can be found on its website.

*-*-**-***-*****-********-*************
PREREQUISITES
*-*-**-***-*****-********-*************
Please have the following software packages available on your systems
before running the demo.

1. Java version 1.4.2_04 or later (earlier versions of 1.4.2 had problems with the https:// protocol).
2. Java Beans Activation Framework 1.1: http://java.sun.com/javase/technologies/desktop/javabeans/jaf/downloads/index.html
3. Jakarta Commons discovery 0.2: http://commons.apache.org/discovery/
4. Apache Axis 1.3: http://ws.apache.org
5. JavaMail 1.4: http://java.sun.com
6. J2EE 1.4.2: http://java.sun.com/j2ee/1.4/download.html
7. Download the Amazon MIME WSDL file from https://sellercentral.amazon.com/help/merchant_documents/WSDL/merchant-interface-mime.wsdl


*-*-**-***-*****-********-*************
RELEASE NOTES 
*-*-**-***-*****-********-*************
(1) Carefully follow all instructions in INSTALLATION_GUIDE.txt 
(2) You must have set up an Amazon Seller account & have your merchant token
(3) To read more about your merchant token, please view Seller Central help: https://sellercentral.amazon.com/gp/help/


*-*-**-***-*****-********-*************
SUPPORT & PROJECT HOME
*-*-**-***-*****-********-*************
	The latest documentation on Checkout by Amazon can be found at in the LINKS section below.

*-*-**-***-*****-********-*************
LINKS
*-*-**-***-*****-********-*************
	Checkout by Amazon Documentation & Seller Central
		https://sellercentral.amazon.com/gp/help/ 