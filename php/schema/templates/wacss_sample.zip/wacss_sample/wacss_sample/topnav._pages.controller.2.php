<?php
	global $PAGE;
	global $PASSTHRU;
	switch(strtolower($PASSTHRU[0])){
		default:
			$recs=topnavGetPages();
			setView('default');
		break;
	}
?>