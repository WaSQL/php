function topnavSampleFunction() {

}