function footerSampleFunction() {

}