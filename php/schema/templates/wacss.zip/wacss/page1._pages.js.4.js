function page1SampleFunction() {

}