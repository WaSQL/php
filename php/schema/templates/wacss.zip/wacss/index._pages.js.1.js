function indexSampleFunction() {

}