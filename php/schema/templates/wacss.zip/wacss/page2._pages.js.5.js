function page2SampleFunction() {

}