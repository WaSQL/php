<?php
	global $USER;
	global $PASSTHRU;
	switch(strtolower($PASSTHRU[0])){
		default:
			setView('default');
		break;
	}
?>
