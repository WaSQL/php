function indexSampleFunction() {

}
