<?php
function footerGetPages(){
	$opts=array(
		'-table'=>'_pages',
		'-where'=>'sort_order > 0',
		'-order'=>'sort_order,name',
		'-fields'=>'_id,name,title'
	);
	$recs=getDBRecords($opts);
	//echo "Pages".printValue($opts).printValue($recs);exit;
	return $recs;
}
?>
