<?php
	if(!isDBTable('contact_form')){
		$ok=contactCreateTable();
	}
	switch(strtolower($_REQUEST['func'])){
    	case 'thankyou':
			setView('thankyou',1);
			$sendopts=array(
				'-format'	=>'email',
				'to'		=>'YOUR EMAIL ADDRESS',
				'from'		=> "Contact Form: {$_REQUEST['name']} <{$_REQUEST['email']}>",
				'subject'	=> $_REQUEST['subject']
			);
			return;
		break;
	}
?>
