<?php
	switch(strtolower($_REQUEST['passthru'][0])){
		default:
			$pages=footerGetPages();
			setView('default');
		break;
	}
?>
