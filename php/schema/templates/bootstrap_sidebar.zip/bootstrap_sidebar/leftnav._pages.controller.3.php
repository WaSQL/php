<?php
	switch(strtolower($_REQUEST['passthru'][0])){
		default:
			$pages=leftnavGetPages();
			setView('default');
		break;
	}
?>
