<?php
	switch(strtolower($_REQUEST['passthru'][0])){
		default:
			setView('default');
		break;
	}
?>
