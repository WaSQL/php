function page2SampleFunction() {

}
