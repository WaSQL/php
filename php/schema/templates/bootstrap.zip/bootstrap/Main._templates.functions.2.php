<?php
loadExtrasJs('jquery1');
global $PAGE;
function templateActiveMenu($name){
	global $PAGE;
	if($PAGE['name']==$name){return ' active';}
	return '';
}
function templateMetaEtag(){
	global $PAGE;
	global $TEMPLATE;
	//get latest edit date and latest create date and sha1 encode them
	return sha1($PAGE['_cdate'].$PAGE['_edate'].$TEMPLATE['_cdate'].$TEMPLATE['_edate']);
}
function templateMetaImage(){
	global $PAGE;
	if(strlen($PAGE['meta_image'])){return "//{$_SERVER['HTTP_HOST']}/{$PAGE['meta_image']}";}
	return '/images/logo.svg';
}
function templateMetaImageType(){
	global $PAGE;
	if(strlen($PAGE['meta_image'])){return 'image/'.getFileExtension($PAGE['meta_image']);}
	return 'image/svg';
}
function templateMetaTitle(){
	global $PAGE;
	if(strlen($PAGE['title'])){return $PAGE['title'];}
	//enter default title below
	return '';
}
function templateMetaSite(){
	global $PAGE;
	if(strlen($PAGE['meta_site'])){return $PAGE['meta_site'];}
	return $_SERVER['HTTP_HOST'];
}
function templateMetaDescription(){
	global $PAGE;
	if(strlen($PAGE['meta_description'])){return $PAGE['meta_description'];}
	//enter default description below
	return '';
}
function templateMetaKeywords(){
	global $PAGE;
	if(strlen($PAGE['meta_keywords'])){return $PAGE['meta_keywords'];}
	//enter default keywords below
	return '';
}
?>
