function leftnavSampleFunction() {

}
