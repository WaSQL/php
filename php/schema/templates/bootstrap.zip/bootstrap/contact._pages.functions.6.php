<?php
function contactForm(){
	return addeditDBForm(array(
		'-table'=>"contact_form",
		'-fields'=>getView('contact_fields'),
		'-id'=> "contact-form",
		'func'=>'thankyou',
		'-focus'=>'name',
		'-save'=>'Send',
		'_template'=>1,
		'-onsubmit'=>"ajaxSubmitForm(this,'centerpop');return false;",
		'name_class'	=> 'form-control',
		'email_class'	=> 'form-control',
		'subject_class'	=> 'form-control',
		'message_class'	=> 'form-control',
		'-save_class'	=> 'btn btn-default'
	));
}
function contactCreateTable(){
	$fields=array(
		'_id'	=> databasePrimaryKeyFieldString(),
		'_cdate'=> databaseDataType('datetime').databaseDateTimeNow(),
		'_cuser'=> databaseDataType('int')." NOT NULL",
		'_edate'=> databaseDataType('datetime')." NULL",
		'_euser'=> databaseDataType('int')." NULL",
	);
	$fields['name']=databaseDataType('varchar(150)')." NULL";
	$fields['email']=databaseDataType('varchar(255)')." NOT NULL";
	$fields['subject']=databaseDataType('varchar(150)')." NOT NULL";
	$fields['message']="text NULL";
	$ok = createDBTable('contact_form',$fields,'InnoDB');
	$id=addDBRecord(array('-table'=>"_fielddata",
		'tablename'		=> 'contact_form',
		'fieldname'		=> 'name',
		'inputtype'		=> 'text',
		'width'			=> 300,
		'inputmax'		=> 150,
	));
	$id=addDBRecord(array('-table'=>"_fielddata",
		'tablename'		=> 'contact_form',
		'fieldname'		=> 'email',
		'inputtype'		=> 'text',
		'width'			=> 300,
		'inputmax'		=> 255,
		'mask'			=> 'email',
		'required'		=> 1
	));
	$id=addDBRecord(array('-table'=>"_fielddata",
		'tablename'		=> 'contact_form',
		'fieldname'		=> 'subject',
		'inputtype'		=> 'text',
		'width'			=> 300,
		'inputmax'		=> 150,
		'required'		=> 1
	));
	$id=addDBRecord(array('-table'=>"_fielddata",
		'tablename'		=> 'contact_form',
		'fieldname'		=> 'message',
		'inputtype'		=> 'textarea',
		'width'			=> 300,
		'height'		=> 150
	));
}
?>
