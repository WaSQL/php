function page1SampleFunction() {

}
