<?php
	global $USER;
	global $PASSTHRU;
	switch(strtolower($PASSTHRU[0])){
		default:
			$pages=leftnavGetPages();
			setView('default');
		break;
	}
?>
