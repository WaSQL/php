function footerSampleFunction() {

}
